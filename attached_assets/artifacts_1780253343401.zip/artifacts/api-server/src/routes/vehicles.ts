import { Router, type IRouter } from "express";
import { eq, and, gte, lte, ilike } from "drizzle-orm";
import { db, vehiclesTable } from "@workspace/db";
import {
  ListVehiclesQueryParams,
  CreateVehicleBody,
  UpdateVehicleBody,
  GetVehicleParams,
  UpdateVehicleParams,
  DeleteVehicleParams,
  GetVehicleResponse,
  UpdateVehicleResponse,
  ListVehiclesResponse,
  GetFeaturedVehiclesResponse,
  GetVehicleStatsResponse,
} from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();

// Serialize a DB vehicle row (Date -> string for Zod)
function serializeVehicle(v: typeof vehiclesTable.$inferSelect) {
  return { ...v, createdAt: v.createdAt instanceof Date ? v.createdAt.toISOString() : v.createdAt };
}

// GET /vehicles/featured — must be before /:id
router.get("/vehicles/featured", async (req, res): Promise<void> => {
  const vehicles = await db
    .select()
    .from(vehiclesTable)
    .where(eq(vehiclesTable.featured, true))
    .orderBy(vehiclesTable.createdAt)
    .limit(6);
  res.json(GetFeaturedVehiclesResponse.parse(vehicles.map(serializeVehicle)));
});

// GET /vehicles/stats
router.get("/vehicles/stats", async (_req, res): Promise<void> => {
  const allVehicles = await db.select().from(vehiclesTable);
  const total = allVehicles.length;
  const peugeot = allVehicles.filter(v => v.brand.toLowerCase() === "peugeot").length;
  const porter = allVehicles.filter(v => v.brand.toLowerCase() === "porter").length;
  const featured = allVehicles.filter(v => v.featured).length;
  const prices = allVehicles.map(v => v.price).filter(p => p != null);
  const minPrice = prices.length > 0 ? Math.min(...prices) : null;
  const maxPrice = prices.length > 0 ? Math.max(...prices) : null;

  res.json(GetVehicleStatsResponse.parse({ total, peugeot, porter, featured, minPrice, maxPrice }));
});

// GET /vehicles
router.get("/vehicles", async (req, res): Promise<void> => {
  const parsed = ListVehiclesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { brand, model, year, minPrice, maxPrice, featured } = parsed.data;
  const conditions = [];

  if (brand) conditions.push(ilike(vehiclesTable.brand, `%${brand}%`));
  if (model) conditions.push(ilike(vehiclesTable.model, `%${model}%`));
  if (year) conditions.push(eq(vehiclesTable.year, Number(year)));
  if (minPrice) conditions.push(gte(vehiclesTable.price, Number(minPrice)));
  if (maxPrice) conditions.push(lte(vehiclesTable.price, Number(maxPrice)));
  if (featured !== undefined) conditions.push(eq(vehiclesTable.featured, Boolean(featured)));

  const vehicles = conditions.length > 0
    ? await db.select().from(vehiclesTable).where(and(...conditions)).orderBy(vehiclesTable.createdAt)
    : await db.select().from(vehiclesTable).orderBy(vehiclesTable.createdAt);

  res.json(ListVehiclesResponse.parse(vehicles.map(serializeVehicle)));
});

// POST /vehicles (admin only)
router.post("/vehicles", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateVehicleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const [vehicle] = await db
    .insert(vehiclesTable)
    .values({
      brand: data.brand,
      model: data.model,
      year: data.year,
      price: data.price,
      mileage: data.mileage ?? null,
      color: data.color ?? null,
      transmission: data.transmission ?? null,
      fuelType: data.fuelType ?? null,
      engineSize: data.engineSize ?? null,
      description: data.description ?? null,
      images: data.images ?? [],
      featured: data.featured ?? false,
      condition: data.condition ?? null,
    })
    .returning();

  res.status(201).json(GetVehicleResponse.parse(serializeVehicle(vehicle)));
});

// GET /vehicles/:id
router.get("/vehicles/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetVehicleParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [vehicle] = await db
    .select()
    .from(vehiclesTable)
    .where(eq(vehiclesTable.id, params.data.id));

  if (!vehicle) {
    res.status(404).json({ error: "Vehicle not found" });
    return;
  }

  res.json(GetVehicleResponse.parse(serializeVehicle(vehicle)));
});

// PATCH /vehicles/:id (admin only)
router.patch("/vehicles/:id", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = UpdateVehicleParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateVehicleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = {};
  const body = parsed.data;
  if (body.brand !== undefined) updateData.brand = body.brand;
  if (body.model !== undefined) updateData.model = body.model;
  if (body.year !== undefined) updateData.year = body.year;
  if (body.price !== undefined) updateData.price = body.price;
  if (body.mileage !== undefined) updateData.mileage = body.mileage;
  if (body.color !== undefined) updateData.color = body.color;
  if (body.transmission !== undefined) updateData.transmission = body.transmission;
  if (body.fuelType !== undefined) updateData.fuelType = body.fuelType;
  if (body.engineSize !== undefined) updateData.engineSize = body.engineSize;
  if (body.description !== undefined) updateData.description = body.description;
  if (body.images !== undefined) updateData.images = body.images;
  if (body.featured !== undefined) updateData.featured = body.featured;
  if (body.condition !== undefined) updateData.condition = body.condition;

  if (Object.keys(updateData).length === 0) {
    res.status(400).json({ error: "No fields to update" });
    return;
  }

  const [vehicle] = await db
    .update(vehiclesTable)
    .set(updateData)
    .where(eq(vehiclesTable.id, params.data.id))
    .returning();

  if (!vehicle) {
    res.status(404).json({ error: "Vehicle not found" });
    return;
  }

  res.json(UpdateVehicleResponse.parse(serializeVehicle(vehicle)));
});

// DELETE /vehicles/:id (admin only)
router.delete("/vehicles/:id", requireAdmin, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteVehicleParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [vehicle] = await db
    .delete(vehiclesTable)
    .where(eq(vehiclesTable.id, params.data.id))
    .returning();

  if (!vehicle) {
    res.status(404).json({ error: "Vehicle not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
