import { Router, type IRouter } from "express";
import { db, contactsTable } from "@workspace/db";
import { SubmitContactBody, ListContactsResponse } from "@workspace/api-zod";
import { requireAdmin } from "../middlewares/auth";
import { sendContactEmail } from "../lib/mailer";

const router: IRouter = Router();

function serializeContact(c: typeof contactsTable.$inferSelect) {
  return { ...c, createdAt: c.createdAt instanceof Date ? c.createdAt.toISOString() : c.createdAt };
}

// POST /contacts
router.post("/contacts", async (req, res): Promise<void> => {
  const parsed = SubmitContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const [contact] = await db
    .insert(contactsTable)
    .values({
      name: data.name,
      phone: data.phone,
      email: data.email ?? null,
      message: data.message,
      vehicleId: data.vehicleId ?? null,
    })
    .returning();

  // Fire-and-forget email — don't block the response
  sendContactEmail({
    name: data.name,
    phone: data.phone,
    email: data.email ?? null,
    message: data.message,
    vehicleId: data.vehicleId ?? null,
  }).catch(() => {/* already logged inside sendContactEmail */});

  res.status(201).json(serializeContact(contact));
});

// GET /contacts (admin only)
router.get("/contacts", requireAdmin, async (_req, res): Promise<void> => {
  const contacts = await db
    .select()
    .from(contactsTable)
    .orderBy(contactsTable.createdAt);

  res.json(ListContactsResponse.parse(contacts.map(serializeContact)));
});

export default router;
