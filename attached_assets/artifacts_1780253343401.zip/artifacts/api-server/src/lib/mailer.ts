import nodemailer from "nodemailer";
import { logger } from "./logger";

const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const DEALER_EMAIL = "aabuashour3@gmail.com";

function createTransport() {
  if (!SMTP_USER || !SMTP_PASS) {
    logger.warn("SMTP_USER or SMTP_PASS not set — email sending disabled");
    return null;
  }
  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS,
    },
  });
}

export interface ContactEmailOptions {
  name: string;
  phone: string;
  email?: string | null;
  message: string;
  vehicleId?: number | null;
}

export async function sendContactEmail(opts: ContactEmailOptions): Promise<boolean> {
  const transport = createTransport();
  if (!transport) return false;

  const subject = opts.vehicleId
    ? `استفسار عن سيارة #${opts.vehicleId} — الساحة عمان`
    : `رسالة جديدة من موقع الساحة عمان`;

  const html = `
    <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9f9f9; border-radius: 8px; overflow: hidden;">
      <div style="background: #1a1a2e; padding: 24px 32px;">
        <h2 style="color: #f5c518; margin: 0; font-size: 20px;">الساحة عمان – طبربور</h2>
        <p style="color: #aaa; margin: 4px 0 0; font-size: 13px;">رسالة جديدة من نموذج التواصل</p>
      </div>
      <div style="padding: 32px; background: #fff;">
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666; width: 120px; font-size: 14px;">الاسم</td>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: 600; font-size: 14px;">${opts.name}</td>
          </tr>
          <tr>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666; font-size: 14px;">الهاتف</td>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-size: 14px;">${opts.phone}</td>
          </tr>
          ${opts.email ? `
          <tr>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666; font-size: 14px;">البريد الإلكتروني</td>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-size: 14px;">${opts.email}</td>
          </tr>` : ""}
          ${opts.vehicleId ? `
          <tr>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; color: #666; font-size: 14px;">رقم السيارة</td>
            <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-size: 14px;">#${opts.vehicleId}</td>
          </tr>` : ""}
        </table>
        <div style="margin-top: 24px;">
          <p style="color: #666; font-size: 13px; margin-bottom: 8px;">الرسالة:</p>
          <div style="background: #f5f5f5; border-right: 4px solid #f5c518; padding: 16px; border-radius: 4px; font-size: 14px; line-height: 1.7;">
            ${opts.message.replace(/\n/g, "<br>")}
          </div>
        </div>
      </div>
      <div style="background: #f0f0f0; padding: 16px 32px; text-align: center;">
        <p style="color: #999; font-size: 12px; margin: 0;">تم الإرسال من موقع الساحة عمان — طبربور، عمان</p>
      </div>
    </div>
  `;

  try {
    await transport.sendMail({
      from: `"الساحة عمان" <${SMTP_USER}>`,
      to: DEALER_EMAIL,
      replyTo: opts.email ?? undefined,
      subject,
      html,
    });
    logger.info({ name: opts.name }, "Contact email sent");
    return true;
  } catch (err) {
    logger.error({ err }, "Failed to send contact email");
    return false;
  }
}
