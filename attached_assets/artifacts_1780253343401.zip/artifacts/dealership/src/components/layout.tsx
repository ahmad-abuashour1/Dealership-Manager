import { Link } from "wouter";
import { CarFront, MapPin, Phone, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { SiWhatsapp } from "react-icons/si";

const WA_NUMBER = "962787929281";
const WA_DEFAULT_MSG = encodeURIComponent("مرحباً، أود الاستفسار عن السيارات المتاحة في معرض الساحة عمان.");
const WA_LINK = `https://wa.me/${WA_NUMBER}?text=${WA_DEFAULT_MSG}`;

export function Layout({ children }: { children: React.ReactNode }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground selection:bg-primary selection:text-primary-foreground">
      {/* Top Bar */}
      <div className="bg-card border-b border-border py-2 px-4 md:px-8 flex justify-between items-center text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 hover:text-primary transition-colors">
            <MapPin className="h-3.5 w-3.5" />
            الأردن، عمان، طبربور
          </span>
          <a href="tel:0787929281" className="flex items-center gap-1.5 hover:text-primary transition-colors">
            <Phone className="h-3.5 w-3.5" />
            078 792 9281
          </a>
        </div>
        <div className="hidden md:flex gap-4">
          <span className="font-semibold text-peugeot">Peugeot</span>
          <span className="font-semibold text-porter">Porter</span>
        </div>
      </div>

      {/* Main Nav */}
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="bg-primary text-primary-foreground p-1.5 rounded-md group-hover:bg-primary/90 transition-colors">
              <CarFront className="h-6 w-6" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-none tracking-tight">الساحة عمان</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">طبربور</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-8 font-medium">
            <Link href="/" className="text-sm hover:text-primary transition-colors relative after:absolute after:bottom-[-20px] after:left-0 after:right-0 after:h-[2px] after:bg-primary after:opacity-0 hover:after:opacity-100 after:transition-opacity">الرئيسية</Link>
            <Link href="/inventory" className="text-sm hover:text-primary transition-colors">المعرض</Link>
            <Link href="/contact" className="text-sm hover:text-primary transition-colors">اتصل بنا</Link>
            <Button asChild variant="default" className="rounded-full px-6 font-bold shadow-md shadow-primary/20 hover:shadow-primary/40 transition-all">
              <Link href="/contact">احجز موعداً</Link>
            </Button>
          </nav>

          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-card p-4 flex flex-col gap-4 animate-in slide-in-from-top-2">
            <Link href="/" onClick={() => setMobileMenuOpen(false)} className="text-sm font-medium py-2">الرئيسية</Link>
            <Link href="/inventory" onClick={() => setMobileMenuOpen(false)} className="text-sm font-medium py-2">المعرض</Link>
            <Link href="/contact" onClick={() => setMobileMenuOpen(false)} className="text-sm font-medium py-2">اتصل بنا</Link>
          </div>
        )}
      </header>

      <main className="flex-1 flex flex-col">
        {children}
      </main>

      {/* Floating WhatsApp bubble */}
      <a
        href={WA_LINK}
        target="_blank"
        rel="noopener noreferrer"
        data-testid="btn-whatsapp-float"
        className="fixed bottom-6 left-6 z-50 flex items-center gap-2 bg-[#25D366] text-white rounded-full shadow-2xl shadow-[#25D366]/40 px-5 py-3 font-bold text-sm hover:bg-[#1ebe5d] hover:scale-105 active:scale-95 transition-all duration-200 group"
        aria-label="تواصل عبر واتساب"
      >
        <SiWhatsapp className="h-5 w-5 shrink-0" />
        <span className="hidden sm:inline whitespace-nowrap">واتساب</span>
      </a>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 md:py-16 mt-auto">
        <div className="container mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="bg-primary text-primary-foreground p-1.5 rounded-md">
                <CarFront className="h-5 w-5" />
              </div>
              <span className="font-bold text-xl">الساحة عمان</span>
            </Link>
            <p className="text-muted-foreground text-sm max-w-sm leading-relaxed mb-6">
              معرض سيارات الساحة عمان في طبربور. نقدم أفضل سيارات بيجو وبورتر التجارية بأعلى معايير الجودة والضمان.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors cursor-pointer">
                <CarFront className="h-4 w-4" />
              </div>
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-foreground">روابط سريعة</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li><Link href="/" className="hover:text-primary transition-colors">الرئيسية</Link></li>
              <li><Link href="/inventory" className="hover:text-primary transition-colors">تصفح المعرض</Link></li>
              <li><Link href="/contact" className="hover:text-primary transition-colors">اتصل بنا</Link></li>
              <li><Link href="/admin/login" className="hover:text-primary transition-colors">إدارة الموقع</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-foreground">معلومات التواصل</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <span>طبربور، عمان، المملكة الأردنية الهاشمية</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 shrink-0 text-primary" />
                <a href="tel:0787929281" dir="ltr" className="hover:text-primary transition-colors">078 792 9281</a>
              </li>
              <li className="text-xs mt-4 pt-4 border-t border-border">
                بإدارة: يزن البشتاوي
              </li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto px-4 md:px-8 mt-12 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} الساحة عمان للسيارات. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
