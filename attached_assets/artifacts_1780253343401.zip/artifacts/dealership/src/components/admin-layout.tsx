import { Link, useLocation } from "wouter";
import { useAdminLogout, useGetAdminMe, getGetAdminMeQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { Car, LayoutDashboard, Plus, PhoneCall, LogOut, Loader2 } from "lucide-react";
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider, SidebarFooter } from "@/components/ui/sidebar";
import { useEffect } from "react";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: user, isLoading, isError } = useGetAdminMe({
    query: {
      queryKey: getGetAdminMeQueryKey(),
      retry: false
    }
  });

  const logout = useAdminLogout({
    mutation: {
      onSuccess: () => {
        queryClient.clear();
        setLocation("/admin/login");
      }
    }
  });

  useEffect(() => {
    if (!isLoading && (isError || !user)) {
      setLocation("/admin/login");
    }
  }, [user, isLoading, isError, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background/50">
        <Sidebar variant="sidebar" side="right" className="border-l border-border bg-card">
          <SidebarHeader className="p-4 border-b border-border">
            <h2 className="text-xl font-bold text-primary tracking-tight">الساحة عمان – الإدارة</h2>
            <p className="text-sm text-muted-foreground mt-1">طبربور</p>
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu className="mt-4 px-2 space-y-1">
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={location === "/admin"}>
                  <Link href="/admin">
                    <LayoutDashboard className="ml-2 h-4 w-4" />
                    <span>لوحة التحكم</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={location === "/admin/vehicles/new"}>
                  <Link href="/admin/vehicles/new">
                    <Plus className="ml-2 h-4 w-4" />
                    <span>إضافة مركبة جديدة</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={location === "/admin/contacts"}>
                  <Link href="/admin/contacts">
                    <PhoneCall className="ml-2 h-4 w-4" />
                    <span>رسائل التواصل</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter className="p-4 border-t border-border">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-foreground">{user?.username}</div>
              <Button variant="ghost" size="icon" onClick={() => logout.mutate()} disabled={logout.isPending}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>
        <main className="flex-1 overflow-auto p-8">
          {children}
        </main>
      </div>
    </SidebarProvider>
  );
}
