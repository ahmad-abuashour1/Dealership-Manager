import { useLocation } from "wouter";
import { Vehicle } from "@workspace/api-client-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Gauge, Calendar, Cog, Fuel } from "lucide-react";
import { cn } from "@/lib/utils";
import { SiWhatsapp } from "react-icons/si";

const WA_NUMBER = "962787929281";

export function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  const [, setLocation] = useLocation();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ar-JO", {
      style: "currency",
      currency: "JOD",
      minimumFractionDigits: 0,
    }).format(price).replace("د.أ.‏", "JOD");
  };

  const isPeugeot = vehicle.brand.toLowerCase() === "peugeot";
  const brandColor = isPeugeot ? "bg-peugeot" : "bg-porter";
  const waText = encodeURIComponent(
    `مرحباً، أنا مهتم بـ ${vehicle.brand.toUpperCase()} ${vehicle.model} ${vehicle.year} — المعروضة بسعر ${vehicle.price.toLocaleString()} JOD. هل ما زالت متاحة؟`
  );

  return (
    <Card
      className="group overflow-hidden rounded-xl border-border/50 bg-card transition-all hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 cursor-pointer"
      onClick={() => setLocation(`/vehicles/${vehicle.id}`)}
      data-testid={`card-vehicle-${vehicle.id}`}
    >
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        {vehicle.images && vehicle.images.length > 0 ? (
          <img
            src={vehicle.images[0]}
            alt={`${vehicle.brand} ${vehicle.model}`}
            className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-muted">
            <span className="text-muted-foreground opacity-50 font-medium tracking-widest uppercase">NO IMAGE</span>
          </div>
        )}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          <Badge variant="secondary" className={cn("font-bold text-white shadow-md border-none", brandColor)}>
            {vehicle.brand.toUpperCase()}
          </Badge>
          {vehicle.condition && (
            <Badge variant="outline" className="bg-background/80 backdrop-blur-sm font-semibold border-none">
              {vehicle.condition === "new" ? "جديد" : "مستعمل"}
            </Badge>
          )}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Header */}
      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start gap-4">
          <h3 className="font-bold text-xl leading-tight line-clamp-2 text-foreground group-hover:text-primary transition-colors">
            {vehicle.model}
          </h3>
          <span className="font-black text-lg text-primary whitespace-nowrap" dir="ltr">
            {formatPrice(vehicle.price)}
          </span>
        </div>
      </CardHeader>

      {/* Specs */}
      <CardContent className="p-4 pt-2">
        <div className="grid grid-cols-2 gap-y-3 text-sm text-muted-foreground mt-2">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-primary/70" />
            <span>{vehicle.year}</span>
          </div>
          {vehicle.mileage !== null && vehicle.mileage !== undefined && (
            <div className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-primary/70" />
              <span dir="ltr">{vehicle.mileage.toLocaleString()} km</span>
            </div>
          )}
          {vehicle.transmission && (
            <div className="flex items-center gap-2">
              <Cog className="h-4 w-4 text-primary/70" />
              <span>{vehicle.transmission === "automatic" ? "اوتوماتيك" : "عادي"}</span>
            </div>
          )}
          {vehicle.fuelType && (
            <div className="flex items-center gap-2">
              <Fuel className="h-4 w-4 text-primary/70" />
              <span>
                {vehicle.fuelType === "petrol" ? "بنزين" :
                  vehicle.fuelType === "diesel" ? "ديزل" :
                  vehicle.fuelType === "electric" ? "كهرباء" : vehicle.fuelType}
              </span>
            </div>
          )}
        </div>
      </CardContent>

      <Separator className="bg-border/50" />

      {/* Footer — two sibling elements, no nested <a> */}
      <CardFooter className="p-4 bg-muted/20 flex items-center justify-between gap-2">
        <span className="text-sm font-semibold text-primary group-hover:underline underline-offset-4">
          عرض التفاصيل
        </span>
        <a
          href={`https://wa.me/${WA_NUMBER}?text=${waText}`}
          target="_blank"
          rel="noopener noreferrer"
          data-testid={`btn-whatsapp-card-${vehicle.id}`}
          onClick={(e) => e.stopPropagation()}
          className="flex items-center gap-1.5 bg-[#25D366] text-white text-xs font-bold px-3 py-1.5 rounded-full hover:bg-[#1ebe5d] transition-colors shrink-0"
          aria-label="تواصل عبر واتساب"
        >
          <SiWhatsapp className="h-3.5 w-3.5" />
          واتساب
        </a>
      </CardFooter>
    </Card>
  );
}
