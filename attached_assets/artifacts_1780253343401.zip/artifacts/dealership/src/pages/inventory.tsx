import { Layout } from "@/components/layout";
import { useListVehicles, getListVehiclesQueryKey } from "@workspace/api-client-react";
import { VehicleCard } from "@/components/vehicle-card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Search, Filter, SlidersHorizontal, Loader2, X, CarFront } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

export default function Inventory() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  
  const [brand, setBrand] = useState<string>(searchParams.get('brand') || "all");
  const [search, setSearch] = useState<string>("");
  const [priceRange, setPriceRange] = useState<number[]>([0, 50000]);

  const { data: vehicles, isLoading } = useListVehicles({
    query: { 
      queryKey: getListVehiclesQueryKey({
        ...(brand !== "all" && { brand }),
        ...(search && { model: search }), // Simplistic search on model
      }) 
    }
  });

  const filteredVehicles = vehicles?.filter(v => {
    return v.price >= priceRange[0] && v.price <= priceRange[1];
  });

  const resetFilters = () => {
    setBrand("all");
    setSearch("");
    setPriceRange([0, 50000]);
  };

  const FilterSidebar = () => (
    <div className="space-y-8">
      <div>
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <Filter className="h-5 w-5 text-primary" /> تصنيف حسب
        </h3>
        
        <div className="space-y-6">
          {/* Brand Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold text-muted-foreground">العلامة التجارية</Label>
            <RadioGroup value={brand} onValueChange={setBrand} className="flex flex-col space-y-2">
              <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="all" id="all" />
                <Label htmlFor="all" className="cursor-pointer">الكل</Label>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="peugeot" id="peugeot" />
                <Label htmlFor="peugeot" className="cursor-pointer">Peugeot بيجو</Label>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="porter" id="porter" />
                <Label htmlFor="porter" className="cursor-pointer">Porter بورتر</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Price Range */}
          <div className="space-y-4">
            <Label className="text-sm font-semibold text-muted-foreground flex justify-between">
              <span>نطاق السعر (دينار)</span>
            </Label>
            <Slider
              value={priceRange}
              min={0}
              max={50000}
              step={1000}
              onValueChange={setPriceRange}
              className="mt-6"
            />
            <div className="flex justify-between text-xs font-medium" dir="ltr">
              <span>{priceRange[0].toLocaleString()} JOD</span>
              <span>{priceRange[1].toLocaleString()} JOD</span>
            </div>
          </div>

          <Button variant="outline" className="w-full mt-4" onClick={resetFilters}>
            <X className="h-4 w-4 ml-2" /> مسح الفلاتر
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <Layout>
      <div className="bg-card border-b border-border py-8">
        <div className="container mx-auto px-4 md:px-8">
          <h1 className="text-4xl font-black tracking-tight mb-4">معرض السيارات</h1>
          <p className="text-muted-foreground max-w-2xl">
            تصفح تشكيلتنا الواسعة من سيارات بيجو ومركبات بورتر. استخدم الفلاتر للبحث عن السيارة التي تناسب احتياجاتك وميزانيتك.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Desktop Sidebar */}
          <aside className="hidden lg:block w-64 shrink-0">
            <div className="sticky top-24 bg-card border border-border rounded-xl p-6 shadow-sm">
              <FilterSidebar />
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1 space-y-6">
            {/* Search and Mobile Filter */}
            <div className="flex gap-4 items-center">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input 
                  placeholder="ابحث عن موديل السيارة..." 
                  className="pl-4 pr-10 h-12 text-base rounded-full bg-card border-border/60 focus-visible:ring-primary shadow-sm"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="h-12 w-12 rounded-full lg:hidden shrink-0">
                    <SlidersHorizontal className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:w-[400px]" dir="rtl">
                  <SheetHeader>
                    <SheetTitle>فلاتر البحث</SheetTitle>
                  </SheetHeader>
                  <div className="py-6">
                    <FilterSidebar />
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            {/* Results */}
            <div className="mb-4">
              <h2 className="font-semibold text-muted-foreground">
                {isLoading ? "جاري التحميل..." : `النتائج: ${filteredVehicles?.length || 0} سيارة`}
              </h2>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="space-y-4">
                    <div className="aspect-[4/3] w-full rounded-xl bg-muted animate-pulse" />
                    <div className="h-6 w-3/4 bg-muted animate-pulse rounded" />
                    <div className="h-4 w-1/2 bg-muted animate-pulse rounded" />
                  </div>
                ))}
              </div>
            ) : filteredVehicles && filteredVehicles.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredVehicles.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} />
                ))}
              </div>
            ) : (
              <div className="text-center py-32 bg-card rounded-2xl border border-dashed border-border flex flex-col items-center justify-center">
                <CarFront className="h-16 w-16 text-muted-foreground/30 mb-4" />
                <h3 className="text-xl font-bold mb-2">لا توجد نتائج</h3>
                <p className="text-muted-foreground mb-6">لم يتم العثور على سيارات تطابق معايير البحث الخاصة بك.</p>
                <Button onClick={resetFilters} variant="outline">مسح جميع الفلاتر</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
