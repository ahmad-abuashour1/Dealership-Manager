import { AdminLayout } from "@/components/admin-layout";
import { useCreateVehicle, useUpdateVehicle, useGetVehicle, getGetVehicleQueryKey, getListVehiclesQueryKey } from "@workspace/api-client-react";
import { useParams, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2, ArrowRight, Save, ImagePlus, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useState } from "react";

const vehicleSchema = z.object({
  brand: z.enum(["peugeot", "porter"], { required_error: "يرجى اختيار العلامة" }),
  model: z.string().min(2, "الموديل مطلوب"),
  year: z.coerce.number().min(1900).max(new Date().getFullYear() + 1),
  price: z.coerce.number().min(0),
  mileage: z.coerce.number().nullable().optional(),
  color: z.string().nullable().optional(),
  transmission: z.enum(["manual", "automatic"]).nullable().optional(),
  fuelType: z.enum(["petrol", "diesel", "electric"]).nullable().optional(),
  engineSize: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  featured: z.boolean().default(false),
  condition: z.enum(["new", "used"]).nullable().optional(),
});

type VehicleFormValues = z.infer<typeof vehicleSchema>;

export default function AdminVehicleForm() {
  const { id } = useParams<{ id?: string }>();
  const isEdit = !!id;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [newImageUrl, setNewImageUrl] = useState("");

  const { data: vehicle, isLoading: isFetching } = useGetVehicle(Number(id), {
    query: {
      enabled: isEdit,
      queryKey: getGetVehicleQueryKey(Number(id))
    }
  });

  const form = useForm<VehicleFormValues>({
    resolver: zodResolver(vehicleSchema),
    defaultValues: {
      brand: "peugeot",
      model: "",
      year: new Date().getFullYear(),
      price: 0,
      mileage: 0,
      color: "",
      transmission: "automatic",
      fuelType: "petrol",
      engineSize: "",
      description: "",
      featured: false,
      condition: "new",
    },
  });

  useEffect(() => {
    if (isEdit && vehicle) {
      form.reset({
        brand: vehicle.brand as any,
        model: vehicle.model,
        year: vehicle.year,
        price: vehicle.price,
        mileage: vehicle.mileage,
        color: vehicle.color,
        transmission: vehicle.transmission as any,
        fuelType: vehicle.fuelType as any,
        engineSize: vehicle.engineSize,
        description: vehicle.description || "",
        featured: vehicle.featured,
        condition: vehicle.condition as any,
      });
      setImageUrls(vehicle.images || []);
    }
  }, [vehicle, isEdit, form]);

  const createMutation = useCreateVehicle({
    mutation: {
      onSuccess: () => {
        toast({ title: "تم إضافة المركبة بنجاح" });
        queryClient.invalidateQueries({ queryKey: getListVehiclesQueryKey() });
        setLocation("/admin");
      },
      onError: () => toast({ title: "حدث خطأ", variant: "destructive" })
    }
  });

  const updateMutation = useUpdateVehicle({
    mutation: {
      onSuccess: () => {
        toast({ title: "تم تحديث المركبة بنجاح" });
        queryClient.invalidateQueries({ queryKey: getGetVehicleQueryKey(Number(id)) });
        queryClient.invalidateQueries({ queryKey: getListVehiclesQueryKey() });
        setLocation("/admin");
      },
      onError: () => toast({ title: "حدث خطأ", variant: "destructive" })
    }
  });

  const addImage = () => {
    if (newImageUrl.trim() && !imageUrls.includes(newImageUrl.trim())) {
      setImageUrls([...imageUrls, newImageUrl.trim()]);
      setNewImageUrl("");
    }
  };

  const removeImage = (index: number) => {
    setImageUrls(imageUrls.filter((_, i) => i !== index));
  };

  const onSubmit = (data: VehicleFormValues) => {
    const payload = { ...data, images: imageUrls };
    if (isEdit) {
      updateMutation.mutate({ id: Number(id), data: payload });
    } else {
      createMutation.mutate({ data: payload });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  if (isEdit && isFetching) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/admin")} className="rounded-full">
          <ArrowRight className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-black">{isEdit ? "تعديل المركبة" : "إضافة مركبة جديدة"}</h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 pb-20">
          <div className="grid lg:grid-cols-3 gap-8">
            
            {/* Main Info Column */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-border shadow-sm">
                <CardContent className="p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-bold">المعلومات الأساسية</h2>
                    <FormField
                      control={form.control}
                      name="featured"
                      render={({ field }) => (
                        <FormItem className="flex items-center gap-2 space-y-0">
                          <FormLabel className="font-semibold text-amber-500">مركبة مميزة (عرض في الرئيسية)</FormLabel>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="brand"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>العلامة التجارية *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-muted/50 h-12">
                                <SelectValue placeholder="اختر العلامة" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="peugeot">Peugeot بيجو</SelectItem>
                              <SelectItem value="porter">Porter بورتر</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="model"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الموديل *</FormLabel>
                          <FormControl>
                            <Input placeholder="مثال: 3008, Partner..." className="bg-muted/50 h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="year"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>سنة الصنع *</FormLabel>
                          <FormControl>
                            <Input type="number" dir="ltr" className="bg-muted/50 h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>السعر (JOD) *</FormLabel>
                          <FormControl>
                            <Input type="number" dir="ltr" className="bg-muted/50 h-12 font-bold" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border shadow-sm">
                <CardContent className="p-6 space-y-6">
                  <h2 className="text-xl font-bold">المواصفات الفنية</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="condition"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الحالة</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || "new"}>
                            <FormControl>
                              <SelectTrigger className="bg-muted/50 h-12">
                                <SelectValue placeholder="اختر الحالة" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="new">جديد (New)</SelectItem>
                              <SelectItem value="used">مستعمل (Used)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="mileage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الممشى (كم)</FormLabel>
                          <FormControl>
                            <Input type="number" dir="ltr" className="bg-muted/50 h-12" {...field} value={field.value ?? ""} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="transmission"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ناقل الحركة</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || "automatic"}>
                            <FormControl>
                              <SelectTrigger className="bg-muted/50 h-12">
                                <SelectValue placeholder="اختر الناقل" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="automatic">اوتوماتيك</SelectItem>
                              <SelectItem value="manual">عادي</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fuelType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>نوع الوقود</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || "petrol"}>
                            <FormControl>
                              <SelectTrigger className="bg-muted/50 h-12">
                                <SelectValue placeholder="اختر الوقود" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="petrol">بنزين</SelectItem>
                              <SelectItem value="diesel">ديزل</SelectItem>
                              <SelectItem value="electric">كهرباء</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="color"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>اللون الخارجي</FormLabel>
                          <FormControl>
                            <Input className="bg-muted/50 h-12" {...field} value={field.value || ""} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="engineSize"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>حجم المحرك</FormLabel>
                          <FormControl>
                            <Input placeholder="مثال: 1600cc, 2.0L" className="bg-muted/50 h-12" dir="ltr" {...field} value={field.value || ""} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>وصف إضافي</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="أضف أية تفاصيل أخرى هنا..." 
                            className="bg-muted/50 min-h-[150px]" 
                            {...field} 
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </div>

            {/* Images Column */}
            <div className="lg:col-span-1">
              <Card className="border-border shadow-sm sticky top-6">
                <CardContent className="p-6 space-y-4">
                  <h2 className="text-xl font-bold mb-4">صور المركبة</h2>
                  
                  <div className="flex gap-2">
                    <Input 
                      placeholder="رابط الصورة (URL)" 
                      value={newImageUrl} 
                      onChange={(e) => setNewImageUrl(e.target.value)}
                      onKeyDown={(e) => { if(e.key === 'Enter') { e.preventDefault(); addImage(); } }}
                      dir="ltr"
                      className="bg-muted/50 h-10"
                    />
                    <Button type="button" variant="secondary" onClick={addImage}>
                      <ImagePlus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-3 mt-4 max-h-[400px] overflow-y-auto pr-2">
                    {imageUrls.map((url, index) => (
                      <div key={index} className="relative group rounded-lg overflow-hidden border border-border aspect-video">
                        <img src={url} alt="Vehicle preview" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Button type="button" variant="destructive" size="icon" onClick={() => removeImage(index)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {imageUrls.length === 0 && (
                      <div className="aspect-video rounded-lg border border-dashed border-border bg-muted flex items-center justify-center text-muted-foreground text-sm">
                        لم يتم إضافة صور
                      </div>
                    )}
                  </div>

                  <Button type="submit" size="lg" className="w-full h-14 text-lg font-bold mt-8 shadow-lg shadow-primary/20" disabled={isPending}>
                    {isPending ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Save className="mr-2 h-5 w-5" />}
                    {isEdit ? "حفظ التعديلات" : "إضافة المركبة"}
                  </Button>
                </CardContent>
              </Card>
            </div>

          </div>
        </form>
      </Form>
    </AdminLayout>
  );
}
