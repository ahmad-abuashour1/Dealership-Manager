import { AdminLayout } from "@/components/admin-layout";
import { useListVehicles, getListVehiclesQueryKey, useDeleteVehicle, useGetVehicleStats, getGetVehicleStatsQueryKey, useListContacts, getListContactsQueryKey } from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Edit, Trash2, Plus, CarFront, MessageSquare, AlertCircle, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";

export default function AdminDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: isLoadingStats } = useGetVehicleStats({
    query: { queryKey: getGetVehicleStatsQueryKey() }
  });

  const { data: vehicles, isLoading: isLoadingVehicles } = useListVehicles({
    query: { queryKey: getListVehiclesQueryKey() }
  });

  const { data: contacts, isLoading: isLoadingContacts } = useListContacts({
    query: { queryKey: getListContactsQueryKey() }
  });

  const deleteMutation = useDeleteVehicle({
    mutation: {
      onSuccess: () => {
        toast({ title: "تم الحذف بنجاح" });
        queryClient.invalidateQueries({ queryKey: getListVehiclesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetVehicleStatsQueryKey() });
      },
      onError: () => {
        toast({ title: "حدث خطأ", variant: "destructive" });
      }
    }
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ar-JO", {
      style: "currency",
      currency: "JOD",
      minimumFractionDigits: 0,
    }).format(price).replace("د.أ.‏", "JOD");
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">لوحة التحكم الرئيسية</h1>
          <p className="text-muted-foreground">نظرة عامة على نشاط المعرض والمركبات والرسائل.</p>
        </div>
        <Button asChild size="lg" className="font-bold shadow-md shadow-primary/20">
          <Link href="/admin/vehicles/new">
            <Plus className="mr-2 h-5 w-5" />
            إضافة مركبة
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-sm border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي المركبات</CardTitle>
            <CarFront className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">{isLoadingStats ? <Skeleton className="h-8 w-16" /> : stats?.total || 0}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">مركبات بيجو</CardTitle>
            <div className="h-4 w-4 rounded-full bg-peugeot/20 border border-peugeot flex items-center justify-center"><div className="h-1.5 w-1.5 rounded-full bg-peugeot"></div></div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">{isLoadingStats ? <Skeleton className="h-8 w-16" /> : stats?.peugeot || 0}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">مركبات بورتر</CardTitle>
            <div className="h-4 w-4 rounded-full bg-porter/20 border border-porter flex items-center justify-center"><div className="h-1.5 w-1.5 rounded-full bg-porter"></div></div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">{isLoadingStats ? <Skeleton className="h-8 w-16" /> : stats?.porter || 0}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">الرسائل الواردة</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">{isLoadingContacts ? <Skeleton className="h-8 w-16" /> : contacts?.length || 0}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="vehicles" className="w-full">
        <TabsList className="mb-6 bg-card border border-border">
          <TabsTrigger value="vehicles" className="font-semibold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">إدارة المركبات</TabsTrigger>
          <TabsTrigger value="contacts" className="font-semibold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">سجل الرسائل</TabsTrigger>
        </TabsList>

        <TabsContent value="vehicles" className="space-y-4 m-0">
          <Card className="border-border shadow-sm overflow-hidden">
            {isLoadingVehicles ? (
              <div className="p-8 space-y-4">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : vehicles && vehicles.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="w-[100px] text-right font-bold">صورة</TableHead>
                      <TableHead className="text-right font-bold">العلامة</TableHead>
                      <TableHead className="text-right font-bold">الموديل والسنة</TableHead>
                      <TableHead className="text-right font-bold">السعر</TableHead>
                      <TableHead className="text-right font-bold">الحالة</TableHead>
                      <TableHead className="text-left font-bold w-[150px]">إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {vehicles.map((v) => (
                      <TableRow key={v.id} className="group">
                        <TableCell>
                          <div className="w-16 h-12 rounded bg-muted overflow-hidden border border-border">
                            {v.images?.[0] && <img src={v.images[0]} className="w-full h-full object-cover" alt={v.model} />}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={v.brand === 'peugeot' ? 'text-peugeot border-peugeot/30' : 'text-porter border-porter/30'}>
                            {v.brand.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-semibold">{v.model} ({v.year})</TableCell>
                        <TableCell className="font-bold" dir="ltr">{formatPrice(v.price)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {v.featured && <Badge className="bg-amber-500 hover:bg-amber-600">مميزة</Badge>}
                            {v.condition && <Badge variant="secondary">{v.condition === 'new' ? 'جديد' : 'مستعمل'}</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="text-left">
                          <div className="flex justify-end gap-2">
                            <Button asChild variant="outline" size="icon" className="h-8 w-8">
                              <Link href={`/admin/vehicles/${v.id}/edit`}>
                                <Edit className="h-4 w-4" />
                              </Link>
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="destructive" size="icon" className="h-8 w-8">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    هذا الإجراء لا يمكن التراجع عنه. سيتم حذف المركبة نهائياً.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => deleteMutation.mutate({ id: v.id })} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                    تأكيد الحذف
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground flex flex-col items-center justify-center">
                <AlertCircle className="h-10 w-10 mb-4 opacity-50" />
                <p>لا توجد مركبات مضافة حالياً.</p>
              </div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="contacts" className="m-0">
          <Card className="border-border shadow-sm overflow-hidden">
            {isLoadingContacts ? (
               <div className="p-8 space-y-4">
                 {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
               </div>
            ) : contacts && contacts.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="text-right font-bold w-[150px]">التاريخ</TableHead>
                      <TableHead className="text-right font-bold w-[200px]">الاسم / الهاتف</TableHead>
                      <TableHead className="text-right font-bold w-[150px]">رقم المركبة</TableHead>
                      <TableHead className="text-right font-bold">الرسالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contacts.map((c) => (
                      <TableRow key={c.id}>
                        <TableCell className="text-muted-foreground text-sm" dir="ltr">{format(new Date(c.createdAt), 'yyyy-MM-dd HH:mm')}</TableCell>
                        <TableCell>
                          <div className="font-semibold">{c.name}</div>
                          <div className="text-sm text-muted-foreground" dir="ltr">{c.phone}</div>
                          {c.email && <div className="text-xs text-muted-foreground">{c.email}</div>}
                        </TableCell>
                        <TableCell>
                          {c.vehicleId ? (
                            <Link href={`/vehicles/${c.vehicleId}`} className="text-primary hover:underline font-medium">
                              عرض المركبة #{c.vehicleId}
                            </Link>
                          ) : <span className="text-muted-foreground">-</span>}
                        </TableCell>
                        <TableCell className="max-w-[400px]">
                          <p className="truncate text-sm" title={c.message}>{c.message}</p>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground flex flex-col items-center justify-center">
                <MessageSquare className="h-10 w-10 mb-4 opacity-50" />
                <p>لا توجد رسائل واردة حالياً.</p>
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}
