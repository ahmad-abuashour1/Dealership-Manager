import { Layout } from "@/components/layout";
import { useGetVehicle, getGetVehicleQueryKey } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Gauge, Calendar, Cog, Fuel, ChevronRight, Phone, MessageSquare } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { Skeleton } from "@/components/ui/skeleton";

export default function VehicleDetail() {
  const { id } = useParams<{ id: string }>();
  
  const { data: vehicle, isLoading, isError } = useGetVehicle(Number(id), {
    query: {
      enabled: !!id,
      queryKey: getGetVehicleQueryKey(Number(id))
    }
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ar-JO", {
      style: "currency",
      currency: "JOD",
      minimumFractionDigits: 0,
    }).format(price).replace("د.أ.‏", "JOD");
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <Skeleton className="h-8 w-64 mb-8" />
          <div className="grid lg:grid-cols-2 gap-12">
            <Skeleton className="aspect-video w-full rounded-2xl" />
            <div className="space-y-6">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-8 w-1/3" />
              <Skeleton className="h-64 w-full" />
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (isError || !vehicle) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-32 text-center">
          <h2 className="text-2xl font-bold mb-4">المركبة غير موجودة</h2>
          <p className="text-muted-foreground mb-8">عذراً، لم نتمكن من العثور على تفاصيل هذه المركبة.</p>
          <Button asChild>
            <Link href="/inventory">العودة للمعرض</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const isPeugeot = vehicle.brand.toLowerCase() === "peugeot";
  const brandColor = isPeugeot ? "bg-peugeot" : "bg-porter";
  const brandTextColor = isPeugeot ? "text-peugeot" : "text-porter";

  return (
    <Layout>
      <div className="bg-muted/30 border-b border-border py-4">
        <div className="container mx-auto px-4 md:px-8">
          <Link href="/inventory" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            <ChevronRight className="h-4 w-4 ml-1" />
            العودة للنتائج
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 py-12">
        <div className="grid lg:grid-cols-12 gap-12">
          {/* Gallery Section */}
          <div className="lg:col-span-7">
            {vehicle.images && vehicle.images.length > 0 ? (
              <Carousel className="w-full" dir="ltr">
                <CarouselContent>
                  {vehicle.images.map((img, idx) => (
                    <CarouselItem key={idx}>
                      <div className="aspect-[4/3] sm:aspect-video rounded-2xl overflow-hidden border border-border shadow-md">
                        <img src={img} alt={`${vehicle.brand} ${vehicle.model} - ${idx + 1}`} className="w-full h-full object-cover" />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                {vehicle.images.length > 1 && (
                  <>
                    <CarouselPrevious className="left-4 bg-background/80 backdrop-blur" />
                    <CarouselNext className="right-4 bg-background/80 backdrop-blur" />
                  </>
                )}
              </Carousel>
            ) : (
              <div className="aspect-video rounded-2xl bg-muted flex items-center justify-center border border-border">
                <span className="text-muted-foreground font-medium">لا توجد صور متاحة</span>
              </div>
            )}
            
            {/* Description if available */}
            {vehicle.description && (
              <div className="mt-12 bg-card border border-border rounded-2xl p-8 shadow-sm">
                <h3 className="text-2xl font-bold mb-4">وصف المركبة</h3>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                  {vehicle.description}
                </p>
              </div>
            )}
          </div>

          {/* Details Section */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Badge className={`${brandColor} text-white hover:${brandColor} text-sm px-3 py-1`}>
                  {vehicle.brand.toUpperCase()}
                </Badge>
                {vehicle.condition && (
                  <Badge variant="outline" className="text-sm px-3 py-1 border-primary/20 text-primary">
                    {vehicle.condition === 'new' ? 'جديد' : 'مستعمل'}
                  </Badge>
                )}
              </div>
              <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4 text-foreground leading-[1.1]">
                {vehicle.model}
              </h1>
              <div className={`text-4xl font-black ${brandTextColor}`} dir="ltr">
                {formatPrice(vehicle.price)}
              </div>
            </div>

            <Separator className="bg-border/60" />

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-card border border-border/50 rounded-xl p-4 flex items-center gap-4 shadow-sm">
                <div className={`p-3 rounded-full ${brandColor}/10 ${brandTextColor}`}>
                  <Calendar className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-semibold mb-1">سنة الصنع</p>
                  <p className="font-bold text-lg">{vehicle.year}</p>
                </div>
              </div>
              
              <div className="bg-card border border-border/50 rounded-xl p-4 flex items-center gap-4 shadow-sm">
                <div className={`p-3 rounded-full ${brandColor}/10 ${brandTextColor}`}>
                  <Gauge className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-semibold mb-1">الممشى</p>
                  <p className="font-bold text-lg" dir="ltr">{vehicle.mileage ? `${vehicle.mileage.toLocaleString()} km` : '0 km'}</p>
                </div>
              </div>

              <div className="bg-card border border-border/50 rounded-xl p-4 flex items-center gap-4 shadow-sm">
                <div className={`p-3 rounded-full ${brandColor}/10 ${brandTextColor}`}>
                  <Cog className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-semibold mb-1">ناقل الحركة</p>
                  <p className="font-bold text-lg">{vehicle.transmission === 'automatic' ? 'اوتوماتيك' : vehicle.transmission === 'manual' ? 'عادي' : '-'}</p>
                </div>
              </div>

              <div className="bg-card border border-border/50 rounded-xl p-4 flex items-center gap-4 shadow-sm">
                <div className={`p-3 rounded-full ${brandColor}/10 ${brandTextColor}`}>
                  <Fuel className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-semibold mb-1">نوع الوقود</p>
                  <p className="font-bold text-lg">
                    {vehicle.fuelType === 'petrol' ? 'بنزين' : 
                     vehicle.fuelType === 'diesel' ? 'ديزل' : 
                     vehicle.fuelType === 'electric' ? 'كهرباء' : '-'}
                  </p>
                </div>
              </div>
            </div>

            {/* Extra Specs List */}
            <div className="bg-muted/40 rounded-xl p-6 border border-border/50">
              <h3 className="font-bold text-lg mb-4">مواصفات إضافية</h3>
              <ul className="space-y-3">
                {vehicle.color && (
                  <li className="flex justify-between items-center py-2 border-b border-border/50 last:border-0">
                    <span className="text-muted-foreground">اللون الخارجي</span>
                    <span className="font-semibold">{vehicle.color}</span>
                  </li>
                )}
                {vehicle.engineSize && (
                  <li className="flex justify-between items-center py-2 border-b border-border/50 last:border-0">
                    <span className="text-muted-foreground">حجم المحرك</span>
                    <span className="font-semibold">{vehicle.engineSize}</span>
                  </li>
                )}
              </ul>
            </div>

            {/* CTA Box */}
            <div className={`bg-gradient-to-br from-card to-muted rounded-2xl p-6 md:p-8 border ${isPeugeot ? 'border-peugeot/20' : 'border-porter/20'} shadow-lg`}>
              <h3 className="text-xl font-bold mb-2">مهتم بهذه المركبة؟</h3>
              <p className="text-muted-foreground mb-6 text-sm">
                تواصل معنا الآن للحصول على عرض سعر خاص أو لحجز موعد لتجربة القيادة.
              </p>
              <div className="flex flex-col gap-3">
                <Button asChild size="lg" className={`w-full text-lg h-14 ${brandColor} hover:${brandColor}/90 text-white shadow-xl shadow-${brandColor}/20`}>
                  <Link href={`/contact?vehicleId=${vehicle.id}`}>
                    <MessageSquare className="ml-2 h-5 w-5" />
                    احجز الآن
                  </Link>
                </Button>
                <a
                  href={`https://wa.me/962787929281?text=${encodeURIComponent(`مرحباً، أنا مهتم بـ ${vehicle.brand.toUpperCase()} ${vehicle.model} ${vehicle.year} — المعروضة بسعر ${vehicle.price.toLocaleString()} JOD. هل ما زالت متاحة؟`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="btn-whatsapp-detail"
                  className="w-full h-14 flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-white font-bold text-base rounded-md shadow-lg shadow-[#25D366]/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <SiWhatsapp className="h-5 w-5" />
                  تواصل عبر واتساب
                </a>
                <Button asChild variant="outline" size="lg" className="w-full h-14 font-bold border-2">
                  <a href="tel:0787929281" dir="ltr">
                    <Phone className="mr-2 h-5 w-5" />
                    078 792 9281
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
