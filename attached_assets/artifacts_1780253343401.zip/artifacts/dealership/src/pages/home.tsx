import { Layout } from "@/components/layout";
import { useGetFeaturedVehicles, getGetFeaturedVehiclesQueryKey, useGetVehicleStats, getGetVehicleStatsQueryKey } from "@workspace/api-client-react";
import { VehicleCard } from "@/components/vehicle-card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, ArrowLeftCircle, ArrowUpLeft, ChevronLeft, Building2, ShieldCheck, ThumbsUp, Gauge, Phone } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: featuredVehicles, isLoading: isLoadingFeatured } = useGetFeaturedVehicles({
    query: { queryKey: getGetFeaturedVehiclesQueryKey() }
  });

  const { data: stats, isLoading: isLoadingStats } = useGetVehicleStats({
    query: { queryKey: getGetVehicleStatsQueryKey() }
  });

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/40 z-10" />
          <img 
            src="https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?q=80&w=2940&auto=format&fit=crop" 
            alt="Dealership Showroom" 
            className="w-full h-full object-cover object-center"
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-20 pt-20 pb-12">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 mb-6 backdrop-blur-sm text-sm font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              الوكيل المعتمد في طبربور
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-foreground mb-6 leading-[1.1] tracking-tight">
              فخامة القيادة <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-amber-500">
                وقوة الأداء
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-xl leading-relaxed">
              اكتشف تشكيلتنا الحصرية من سيارات بيجو العصرية ومركبات بورتر التجارية. الساحة عمان، خيارك الأول للثقة والتميز.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="h-14 px-8 text-lg rounded-full font-bold shadow-xl shadow-primary/20">
                <Link href="/inventory">
                  تصفح المعرض <ChevronLeft className="mr-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-14 px-8 text-lg rounded-full font-bold bg-background/50 backdrop-blur border-border/50 hover:bg-background/80">
                <Link href="/contact">تواصل معنا</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="border-y border-border bg-card relative z-30 -mt-8 mx-4 md:mx-auto md:max-w-5xl rounded-2xl shadow-xl overflow-hidden">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-x-reverse divide-border/50">
          <div className="p-6 text-center">
            {isLoadingStats ? <Skeleton className="h-10 w-20 mx-auto mb-2" /> : (
              <div className="text-3xl md:text-4xl font-black text-primary mb-1">{stats?.total || 0}</div>
            )}
            <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">سيارة متاحة</div>
          </div>
          <div className="p-6 text-center">
            {isLoadingStats ? <Skeleton className="h-10 w-20 mx-auto mb-2" /> : (
              <div className="text-3xl md:text-4xl font-black text-peugeot mb-1">{stats?.peugeot || 0}</div>
            )}
            <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">مركبات بيجو</div>
          </div>
          <div className="p-6 text-center">
            {isLoadingStats ? <Skeleton className="h-10 w-20 mx-auto mb-2" /> : (
              <div className="text-3xl md:text-4xl font-black text-porter mb-1">{stats?.porter || 0}</div>
            )}
            <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">مركبات بورتر</div>
          </div>
          <div className="p-6 text-center">
            <div className="text-3xl md:text-4xl font-black text-foreground mb-1">+10</div>
            <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">سنوات خبرة</div>
          </div>
        </div>
      </section>

      {/* Brands Highlights */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid md:grid-cols-2 gap-12 lg:gap-24 items-center">
            <div className="order-2 md:order-1 relative">
              <div className="absolute inset-0 bg-peugeot/10 rounded-[3rem] -rotate-6 scale-105 z-0" />
              <img src="https://images.unsplash.com/photo-1549399542-7e3f8b79c341?q=80&w=2574&auto=format&fit=crop" alt="Peugeot Car" className="relative z-10 rounded-3xl shadow-2xl object-cover aspect-[4/3] w-full" />
              <div className="absolute -bottom-6 -right-6 bg-card p-6 rounded-2xl shadow-xl z-20 border border-border">
                <span className="block text-4xl font-black text-peugeot mb-1">Peugeot</span>
                <span className="text-sm text-muted-foreground font-medium">أناقة أوروبية وأداء متميز</span>
              </div>
            </div>
            <div className="order-1 md:order-2 space-y-6">
              <h2 className="text-4xl font-black tracking-tight">اكتشف عالم <span className="text-peugeot">بيجو</span></h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                نقدم لك أحدث طرازات بيجو التي تجمع بين التصميم الجريء، التكنولوجيا المتطورة، وكفاءة استهلاك الوقود. من سيارات الهاتشباك الاقتصادية إلى سيارات الدفع الرباعي العائلية.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 font-medium text-foreground"><ShieldCheck className="h-5 w-5 text-peugeot" /> ضمان شامل وخدمة ما بعد البيع</li>
                <li className="flex items-center gap-3 font-medium text-foreground"><Gauge className="h-5 w-5 text-peugeot" /> تجربة قيادة لا تضاهى</li>
                <li className="flex items-center gap-3 font-medium text-foreground"><Building2 className="h-5 w-5 text-peugeot" /> تصاميم عصرية تناسب كل الأذواق</li>
              </ul>
              <Button asChild variant="outline" className="mt-4 border-peugeot text-peugeot hover:bg-peugeot hover:text-white rounded-full">
                <Link href="/inventory?brand=peugeot">عرض سيارات بيجو</Link>
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-12 lg:gap-24 items-center mt-32">
            <div className="space-y-6">
              <h2 className="text-4xl font-black tracking-tight">الاعتمادية مع <span className="text-porter">بورتر</span></h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                لأصحاب الأعمال والمشاريع، توفر مركبات بورتر التجارية المتانة والقوة التي تحتاجها لإنجاز مهامك بكفاءة عالية وتكلفة تشغيلية منخفضة.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 font-medium text-foreground"><ShieldCheck className="h-5 w-5 text-porter" /> قدرة تحمل أوزان عالية</li>
                <li className="flex items-center gap-3 font-medium text-foreground"><Gauge className="h-5 w-5 text-porter" /> محركات ديزل قوية واقتصادية</li>
                <li className="flex items-center gap-3 font-medium text-foreground"><Building2 className="h-5 w-5 text-porter" /> مساحات تخزين مرنة وعملية</li>
              </ul>
              <Button asChild variant="outline" className="mt-4 border-porter text-porter hover:bg-porter hover:text-white rounded-full">
                <Link href="/inventory?brand=porter">عرض مركبات بورتر</Link>
              </Button>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-porter/10 rounded-[3rem] rotate-6 scale-105 z-0" />
              <img src="https://images.unsplash.com/photo-1605816988069-b11383b50717?q=80&w=2670&auto=format&fit=crop" alt="Commercial Vehicle" className="relative z-10 rounded-3xl shadow-2xl object-cover aspect-[4/3] w-full" />
              <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-2xl shadow-xl z-20 border border-border">
                <span className="block text-4xl font-black text-porter mb-1">Porter</span>
                <span className="text-sm text-muted-foreground font-medium">شريكك الأقوى في العمل</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="py-24 bg-card border-t border-border">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-black mb-4 tracking-tight">السيارات المميزة</h2>
              <p className="text-muted-foreground max-w-2xl">
                مجموعة مختارة بعناية من أفضل السيارات المتوفرة لدينا حالياً في معرض الساحة عمان.
              </p>
            </div>
            <Button asChild variant="ghost" className="font-bold text-primary hover:text-primary/80 hover:bg-primary/10">
              <Link href="/inventory">
                عرض كل السيارات <ChevronLeft className="mr-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          {isLoadingFeatured ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="aspect-[4/3] w-full rounded-xl" />
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              ))}
            </div>
          ) : featuredVehicles && featuredVehicles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {featuredVehicles.slice(0, 4).map((vehicle) => (
                <VehicleCard key={vehicle.id} vehicle={vehicle} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-muted rounded-2xl border border-dashed border-border">
              <p className="text-muted-foreground">لا توجد سيارات مميزة حالياً</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1552519507-da3b142c6e3d?q=80&w=2670&auto=format&fit=crop')] opacity-10 bg-cover bg-center mix-blend-overlay" />
        <div className="container mx-auto px-4 relative z-10 text-center text-primary-foreground">
          <h2 className="text-4xl md:text-5xl font-black mb-6">هل تبحث عن سيارة أحلامك؟</h2>
          <p className="text-xl mb-10 opacity-90 max-w-2xl mx-auto">
            تفضل بزيارة معرضنا في طبربور أو تواصل معنا لحجز تجربة قيادة للسيارة التي تناسبك.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild size="lg" variant="secondary" className="h-14 px-8 text-lg rounded-full font-bold text-primary">
              <Link href="/contact">احجز موعداً الآن</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-14 px-8 text-lg rounded-full font-bold bg-transparent text-primary-foreground border-primary-foreground/30 hover:bg-primary-foreground/10 hover:text-primary-foreground">
              <a href="tel:0787929281" dir="ltr">078 792 9281 <Phone className="ml-2 h-5 w-5" /></a>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
