import { Layout } from "@/components/layout";
import { useSubmitContact } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, Clock, Loader2, Send } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { Card } from "@/components/ui/card";

const contactSchema = z.object({
  name: z.string().min(2, "الاسم مطلوب"),
  phone: z.string().min(8, "رقم الهاتف مطلوب"),
  email: z.string().email("البريد الإلكتروني غير صالح").optional().or(z.literal("")),
  message: z.string().min(10, "الرسالة قصيرة جداً"),
  vehicleId: z.number().nullable().optional(),
});

type ContactFormValues = z.infer<typeof contactSchema>;

export default function Contact() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const vehicleIdParam = searchParams.get('vehicleId');
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      message: vehicleIdParam ? `أنا مهتم بالمركبة رقم: ${vehicleIdParam}` : "",
      vehicleId: vehicleIdParam ? parseInt(vehicleIdParam) : null,
    },
  });

  const submitMutation = useSubmitContact({
    mutation: {
      onSuccess: () => {
        toast({
          title: "تم الإرسال بنجاح",
          description: "شكراً لتواصلك معنا، سنقوم بالرد عليك في أقرب وقت ممكن.",
        });
        form.reset();
      },
      onError: () => {
        toast({
          title: "خطأ في الإرسال",
          description: "حدث خطأ أثناء إرسال رسالتك. يرجى المحاولة مرة أخرى.",
          variant: "destructive"
        });
      }
    }
  });

  const onSubmit = (data: ContactFormValues) => {
    submitMutation.mutate({ data });
  };

  return (
    <Layout>
      <div className="bg-card border-b border-border py-12 md:py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 pattern-grid-lg mix-blend-overlay" />
        <div className="container mx-auto px-4 md:px-8 relative z-10 text-center max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-6">تواصل معنا</h1>
          <p className="text-lg text-muted-foreground">
            فريق الساحة عمان مستعد دائماً للإجابة على استفساراتكم ومساعدتكم في اختيار السيارة الأنسب لاحتياجاتكم.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-6">
            <h3 className="text-2xl font-bold mb-6">معلومات الاتصال</h3>
            
            <Card className="p-6 border-border shadow-sm flex items-start gap-4">
              <div className="bg-primary/10 text-primary p-3 rounded-xl shrink-0">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-bold mb-1">الهاتف المباشر</h4>
                <a href="tel:0787929281" className="text-lg font-semibold hover:text-primary transition-colors block" dir="ltr">
                  078 792 9281
                </a>
                <p className="text-sm text-muted-foreground mt-1">بإدارة: يزن البشتاوي</p>
              </div>
            </Card>

            <Card className="p-6 border-border shadow-sm flex items-start gap-4">
              <div className="bg-primary/10 text-primary p-3 rounded-xl shrink-0">
                <MapPin className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-bold mb-1">موقع المعرض</h4>
                <p className="text-muted-foreground leading-relaxed">
                  الأردن - عمان<br />
                  طبربور
                </p>
              </div>
            </Card>

            <Card className="p-6 border-border shadow-sm flex items-start gap-4">
              <div className="bg-primary/10 text-primary p-3 rounded-xl shrink-0">
                <Clock className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-bold mb-1">ساعات العمل</h4>
                <p className="text-muted-foreground">السبت - الخميس: 9:00 ص - 9:00 م</p>
                <p className="text-muted-foreground">الجمعة: مغلق</p>
              </div>
            </Card>

            <a
              href={`https://wa.me/962787929281?text=${encodeURIComponent("مرحباً، أود الاستفسار عن السيارات المتاحة في معرض الساحة عمان.")}`}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="btn-whatsapp-contact"
              className="flex items-center gap-4 p-6 rounded-xl bg-[#25D366] text-white shadow-lg shadow-[#25D366]/20 hover:bg-[#1ebe5d] hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              <div className="bg-white/20 p-3 rounded-xl shrink-0">
                <SiWhatsapp className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-bold mb-0.5">واتساب</h4>
                <p className="text-white/80 text-sm">تواصل معنا مباشرة عبر واتساب</p>
              </div>
            </a>
          </div>

          {/* Form */}
          <div className="lg:col-span-2">
            <Card className="p-8 md:p-10 border-border shadow-xl">
              <h3 className="text-2xl font-bold mb-8">أرسل رسالة</h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الاسم الكريم</FormLabel>
                          <FormControl>
                            <Input placeholder="أدخل اسمك" {...field} className="bg-muted/50 h-12" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رقم الهاتف</FormLabel>
                          <FormControl>
                            <Input placeholder="07XXXXXXXX" dir="ltr" className="text-right bg-muted/50 h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>البريد الإلكتروني <span className="text-muted-foreground font-normal">(اختياري)</span></FormLabel>
                        <FormControl>
                          <Input placeholder="email@example.com" dir="ltr" className="text-right bg-muted/50 h-12" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>نص الرسالة</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="كيف يمكننا مساعدتك؟" 
                            className="min-h-[150px] resize-y bg-muted/50" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" size="lg" className="w-full md:w-auto h-14 px-8 text-lg font-bold" disabled={submitMutation.isPending}>
                    {submitMutation.isPending ? (
                      <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> جاري الإرسال...</>
                    ) : (
                      <><Send className="mr-2 h-5 w-5" /> إرسال الرسالة</>
                    )}
                  </Button>
                </form>
              </Form>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
